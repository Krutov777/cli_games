#!/usr/bin/env python
def greet(where):
    print('Welcome {}!'.format(where))
    
def main():
    greet('to the Brain Games')
    		
if __name__ == '__main__':
   main()
